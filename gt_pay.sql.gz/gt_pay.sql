-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2021 at 04:28 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gt_pay`
--

-- --------------------------------------------------------

--
-- Table structure for table `merchants`
--

CREATE TABLE `merchants` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `email_address` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `api_key` text NOT NULL,
  `merchant_code` varchar(50) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `merchants`
--

INSERT INTO `merchants` (`id`, `full_name`, `company_name`, `email_address`, `password`, `phone`, `api_key`, `merchant_code`, `date_created`) VALUES
(10, 'Joesph Gbekley', 'JoeStore', 'gbekleyj@gmail.com', '$2y$10$jknpqC9QAp/EyaLjYvggZe4BBHlTGKS4eXKSLk8cHy1vOH.NqdJN2', '02347557565', 'b5f1ba-bcc7a6-063608-269da2-67b117', 'cbed5006a79307aee6cc', '2020-01-19 17:16:13'),
(9, 'Gottfried Ansah', 'Store GH', 'owusuansahg@gmail.com', '$2y$10$pCBzG0S3tkEMiGa3Gd0mL.Tmc3bGJXq8miCEeQ/vkSKutSfhK871q', '0553581722', '06d16f-215044-b5b380-46308d-e7fd65', '123208', '2020-01-18 20:04:47');

-- --------------------------------------------------------

--
-- Table structure for table `store_items`
--

CREATE TABLE `store_items` (
  `id` int(11) NOT NULL,
  `item` varchar(255) NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_items`
--

INSERT INTO `store_items` (`id`, `item`, `amount`, `description`, `image`, `date_created`) VALUES
(3, 'Windows Darkened Software Package - Full Version', '1200.00', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s.', 'http://localhost/store/images/windows_dark.jpg', '2020-01-19 20:06:49'),
(4, 'Windows Blue Color Software Package - Full Version', '1400.00', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s.', 'http://localhost/store/images/windows_blue.jpg', '2020-01-19 20:06:49'),
(5, 'Windows Colour Software Package - Full Version', '1600.00', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s.', 'http://localhost/store/images/windows_color.jpg', '2020-01-19 20:06:49'),
(6, 'Windows Blue Screen Software Package - Full Version', '1800.00', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s.', 'http://localhost/store/images/blue_screen.jpg', '2020-01-19 20:06:49');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `auth` varchar(225) NOT NULL,
  `status` varchar(255) NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `card_number` int(60) DEFAULT NULL,
  `expiry` varchar(10) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `merchant_code` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `system_id` varchar(255) NOT NULL,
  `product` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `return_url` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `auth`, `status`, `amount`, `first_name`, `last_name`, `email`, `phone`, `card_number`, `expiry`, `country`, `merchant_code`, `order_id`, `system_id`, `product`, `description`, `return_url`, `date_created`, `date_updated`) VALUES
(49, '59e0f611457840c7328c', 'Payment Successful', '1800.00', 'Gottfried', 'Ansah', 'owusuansahg@gmail.com', '0553581722', 400010, '0323', 'GH', 'cbed5006a79307aee6cc', '5e28235a773a2', '5e28235a89c3c', 'Windows Blue Screen Software Package - Full Version', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s.', 'http://localhost/store/index.php', '2020-01-22 10:26:34', '2020-01-22 10:26:49'),
(48, '2588e32b9b368bee10ff', 'Payment Refunded', '1400.00', 'Augustus', 'Buckwild', 'augusbuckwild@gmail.com', '0264458923', 400010, '0323', 'GH', 'cbed5006a79307aee6cc', '5e27375d5daec', '5e27375d6c73e', 'Windows Blue Color Software Package - Full Version', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s.', 'http://localhost/store/index.php', '2020-01-21 17:39:41', '2020-01-21 05:40:08'),
(50, '3d22c2415ba4d779fb3b', 'Payment Cancelled', '1600.00', 'Alexander', 'Eugene', 'owusuansahg@gmail.com', '0553581722', NULL, NULL, NULL, 'cbed5006a79307aee6cc', '5e28bf6f4cc60', '5e28bf6f6f68c', 'Windows Colour Software Package - Full Version', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s.', 'http://localhost/store/index.php', '2020-01-22 21:32:31', '2020-01-22 09:32:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `merchants`
--
ALTER TABLE `merchants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `store_items`
--
ALTER TABLE `store_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `merchants`
--
ALTER TABLE `merchants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `store_items`
--
ALTER TABLE `store_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
